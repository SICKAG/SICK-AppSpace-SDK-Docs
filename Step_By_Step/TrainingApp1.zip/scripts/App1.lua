
Log.setLevel("ALL")

-- Variable for storing current set cycle time
local cycleTime = 1000

-- Creating image provider
local provider = Image.Provider.Directory.create()

-- Creating QR code reader
local qrReader = Image.CodeReader.QR.create()

local viewer = View.create()

-- Function to configure and starting provider
local function configureAndStart()
  Image.Provider.Directory.stop(provider)
  Image.Provider.Directory.setPath(provider, "resources")
  Image.Provider.Directory.setCycleTime(provider, cycleTime)
  Image.Provider.Directory.start(provider)
end


-- Function registered to Engine.OnStarted event which is raised once after start
local function main()
  -- write app code in local scope, using API
  print("Hello World")
  -- Call function to configure and start provider
  configureAndStart()
end
Script.register("Engine.OnStarted", main)
-- serve API in global scope

-- Function is called everytime a new image is provided
--@handleOnNewImage(image:Image,sensorData:SensorData)
local function handleOnNewImage(image, sensorData)
  Log.info("New image received")

  -- Adding image to viewer and update
  View.addImage(viewer, image)
  View.present(viewer)

  -- Variable to store content string
  local content = "[No code found]"
  -- Searching and decoding all codes in the image
  local result = Image.CodeReader.QR.decode(qrReader, image)
  -- Choosing first decoding result
  local firstResult = result[1]
  -- If found at least one code, retrieve its content
  if firstResult then
    content = Image.CodeReader.Result.getContent(firstResult)
  end
  -- Printing code content to console
  print("Code content: " .. content)
  -- Notifying served event
  Script.notifyEvent("OnProcessingFinished", content)

end
Image.Provider.Directory.register(provider, "OnNewImage", handleOnNewImage)

-- Served function to set cycle time
--@setCycleTime(newCycleTime:int):
local function setCycleTime(newCycleTime)
  Log.info("Setting cycle time to: " .. newCycleTime)
  cycleTime = newCycleTime
  configureAndStart()
end
Script.serveFunction("Training.setCycleTime", setCycleTime)

-- Served function to get cycle time
--@getCycleTime():int
local function getCycleTime()
  return cycleTime
end
Script.serveFunction("Training.getCycleTime", getCycleTime)

-- Served function to take snapshot
--@takeSnapshot():
local function takeSnapshot()
  -- Start provider and take only 1 image
  Image.Provider.Directory.stop(provider)
  Image.Provider.Directory.start(provider, 1)
end
Script.serveFunction("Training.takeSnapshot", takeSnapshot)

Script.serveEvent("Training.OnProcessingFinished", "OnProcessingFinished")
