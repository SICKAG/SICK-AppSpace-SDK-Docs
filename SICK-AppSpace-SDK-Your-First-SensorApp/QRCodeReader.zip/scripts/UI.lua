-- Private variables and settings

local viewer = View.create("viewer2D")

-- Private functions and handling

-- required for the display of previously scanned code content
Script.serveEvent("UI.OnNewContent", "OnNewContent")

-- Exported functions

---Visualize image and read content
---@param img Image
local function displayImage(img)
  local IMAGE_ID = "Image1"

  viewer:clear()
  viewer:addImage(img, nil , IMAGE_ID)
  viewer:present()
end

---Function to visualize image and codes on the UI
---@param img Image
---@param codes Image.CodeReader.Result[]
---@param contentIsValid bool
local function visualizeResult(img, codes, contentIsValid)
  -- Processing and view output
  local IMAGE_ID = "Image1"

  -- Visualize image and read content

  local content = ""

  for _, code in ipairs(codes) do
    content = tostring(code:getContent())

    local shape = code:getRegion()
    local center = shape:getCenterOfGravity()

    local codeDecoration = View.ShapeDecoration.create()
    codeDecoration:setLineWidth(5)

    local textDeco = View.TextDecoration.create()
    textDeco:setSize(45)
    textDeco:setPosition(center:getX() - 100, (center:getY() + 150))

    -- *6.* Console entry and overlay colors based on comparison of code content and target content
    -- if contentIsValid then
    --   textDeco:setColor(0, 255, 0)
    --   codeDecoration:setLineColor(0, 255, 0)
    -- elseif contentIsValid == false and contentIsValid ~= nil then
    --   textDeco:setColor(255, 0, 0)
    --   codeDecoration:setLineColor(255, 0, 0)
    -- end

    viewer:addText(content, textDeco, nil, IMAGE_ID)
    viewer:addShape(shape, codeDecoration, nil, IMAGE_ID)
  end

  Script.notifyEvent("OnNewContent", content)
  

  viewer:present()
end

---Serves provided function for provided CROWN
---@param crownName string
---@param fun function
local function serve(crownName, fun)
  Script.serveFunction(crownName, fun)
end

return {
  displayImage = displayImage,
  visualizeResult = visualizeResult,
  serve = serve
}