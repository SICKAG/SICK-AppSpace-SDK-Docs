-- Initializing other scripts as pseudo-classes
local paramsHandling = require("ParamsHandling")
local processing = require("Processing")
local UI = require("UI")

local imageAcquisition

local success, isEngine = pcall(Engine.isEmulator)

if not success then
  isEngine = Engine.getTypeName() == "SICK AppEngine"
end

if isEngine then
  imageAcquisition = require("Directory")
else
  imageAcquisition = require("Camera")
end

-- Wrapper functions

---Handles new images - first it clears view and displays the new image, then it handles over next steps to the processImage function
---@param img Image Received image
---@param senData SensorData Information about acquisition device state
local function handleOnNewImage(img, senData)
  UI.displayImage(img)
  processing.processImage(img, senData, UI.visualizeResult)
end
imageAcquisition.registerOnNewImage(handleOnNewImage)

---Wrapper that sets cycle time on image acquisition provider and stores the parameter if change was successful
---@param cycleTime integer Cycle time in miliseconds
local function setCycleTime(cycleTime)
  if imageAcquisition.setCycleTime(cycleTime) then
    paramsHandling.setParam("cycleTime", cycleTime)
  end
end

---Wrapper that sets exposure time on image acquisition provider and stores the parameter if change was successful. Only valid when working with InspectorP.
---@param time integer Exposure time in microseconds
local function setExposureTime(time)
  if isEngine then
    Log.warning("No exposure time setting in AppEngine mode")
  else
    if imageAcquisition.setExposureTime(time) then
      paramsHandling.setParam("exposure",time)
    end
  end
end


---Wrapper that sets gain on image acquisition provider and stores the parameter if change was successful. Only valid when working with InspectorP.
---@param gain integer Gain value
local function setGain(gain)
  if isEngine then
    Log.warning("No gain setting in AppEngine mode")
  else
    if imageAcquisition.setGain(gain) then
      paramsHandling.setParam("gain",gain)
    end
  end
end

---Wrapper that sets image acquisition provider to use images from directory or from live capture and stores the parameter if change was successful. Only valid when working with InspectorP.
---@param liveMode boolean true - camera will capture live images, false - device will source images from resources folder
local function setLiveMode(liveMode)
  if isEngine then
    Log.warning("No live mode setting in AppEngine mode")
  else
    if imageAcquisition.setLiveMode(liveMode, {handleOnNewImage}) then
      paramsHandling.setParam("liveMode", liveMode)
    end
  end
end

---Wrapper that sets trigger on image acquisition provider and stores the parameter if change was successful.
---@param triggerMode boolean true - acquisition will be triggered automatically by timer, false - acqusition will be performed whem explicitely triggered with a function
local function setTriggerMode(triggerMode)
  if triggerMode then
    if imageAcquisition.start() then
      paramsHandling.setParam("autoTrigger",triggerMode)
    end
  else
    if imageAcquisition.stop() then
      paramsHandling.setParam("autoTrigger",triggerMode)
    end
  end
end

-- local funtion startManualTrigger()

-- end


-- Registrations for UI elements

UI.serve("UI.setCycleTime", setCycleTime)
UI.serve("UI.setExposureTime", setExposureTime)
UI.serve("UI.setGain", setGain)
UI.serve("UI.setLiveMode", setLiveMode)
UI.serve("UI.setTriggerMode", setTriggerMode)
UI.serve("UI.setValidContent", processing.setValidContent)
UI.serve("UI.getCycleTime", function() return paramsHandling.getParam("cycleTime") end)
UI.serve("UI.getExposureTime", function() return paramsHandling.getParam("exposure") end)
UI.serve("UI.getGain", function() return paramsHandling.getParam("gain") end)
UI.serve("UI.getLiveMode", function() return paramsHandling.getParam("liveMode") end)
UI.serve("UI.getTriggerMode", function() return paramsHandling.getParam("autoTrigger") end)
UI.serve("UI.getValidContent", function() return processing.getValidContent() end)
UI.serve("UI.getIsEngine", function() return isEngine end)



---Initialize parameters from loaded config
local function handleOnStarted()
  setCycleTime(paramsHandling.getParam("cycleTime"))
  setTriggerMode(paramsHandling.getParam("autoTrigger"))
  if not isEngine then
    setExposureTime(paramsHandling.getParam("exposure"))
    setGain(paramsHandling.getParam("gain"))
    if not paramsHandling.getParam("liveMode") then
      setLiveMode(paramsHandling.getParam("liveMode"))
    end
  end
end
Script.register('Engine.OnStarted', handleOnStarted)

