-- Private variables and settings

local savefile = "private/params.json"

local params = {
  exposure = 100,
  gain = 1,
  cycleTime = 1000,
  liveMode = true,
  autoTrigger = false
}

local saveTimer = Timer.create()
saveTimer:setExpirationTime(1000)
saveTimer:setPeriodic(false)

-- Private functions and handling

local function storeToFile()
  local stringbuffer = "{"
  for paramName, value in pairs(params) do
    stringbuffer = ("%s\"%s\": %s, "):format(stringbuffer,paramName,tostring(value))
  end
  stringbuffer = stringbuffer:sub(1,-3).."}"

  local f = File.open(savefile, "w")
  f:write(stringbuffer)
  f:close()
end
saveTimer:register("OnExpired", storeToFile)

local function readFromFile()
  if File.exists(savefile) then
    local f = File.open(savefile, "r")
    local stringbuffer = f:read()
    f:close()

    for rec in string.gmatch(stringbuffer, '"%w+": [%w%d]+') do
      local paramName = string.match(rec, '"(%w+)"')
      local value = string.match(rec, '"%w+": ([%w%d]+)')
      if value == "true" or value == "false" then
        value = value == "true"
      else
        value = tonumber(value)
      end
      if params[paramName] ~= nil then
        if type(params[paramName]) == type(value) then
          params[paramName] = value
        else
          Log.severe(("Error on reading file: Wrong param value type of param %s. Expected %s, got %s"):format(paramName, type(params[paramName]),type(value)))
          error()
        end
      else
        Log.severe("Error on reading file: Unknown parameter " .. tostring(paramName))
        error()
      end
    end
  else
    Log.warning("No file to read from. Ignore if it is first start.")
  end
end

local function startSaveTimer()
  if saveTimer:isRunning() then
    saveTimer:stop()
  end
  saveTimer:start()
end

readFromFile()

-- Exported functions

---Set a value of a parameter for storage
---@param paramName "exposure" | "gain" | "cycleTime" | "liveMode" | "autoTrigger"
---@param value boolean | integer
---@return boolean
local function setParam(paramName, value)
  if params[paramName] ~= nil then
    if type(params[paramName]) == type(value) then
      params[paramName] = value
      startSaveTimer()
      return true
    else
      Log.severe(("Wrong param value type of parameter %s. Expected %s, got %s"):format(paramName, type(params[paramName]),type(value)))
      return false
    end
  else
    Log.severe("Unknown parameter "..tostring(paramName))
    return false
  end
end

---Get a value of a parameter from storage
---@param paramName "exposure" | "gain" | "cycleTime" | "liveMode" | "autoTrigger"
---@return boolean | integer
local function getParam(paramName)
  if params[paramName] ~= nil then
    return params[paramName]
  else
    Log.severe("Unknown parameter "..tostring(paramName))
    return false
  end
end

return {
  setParam = setParam,
  getParam = getParam
}