-- Private variables and settings

-- *1.* Create a CodeReader object
-- local qrReader = Image.CodeReader.QR.create()

-- *3.* Define the target code content for comparison
-- local validContent = "SICK AppSpace"

-- *7:* Create handle for accessing feedback LED and beeper (InspectorP only)
-- local feedbackLED = LED.create("FEEDBACK_LED")
-- local intBeeper = Beeper.create()

-- Private functions and handling

---@param wasValidContent bool
local function generateDeviceFeedback(wasValidContent)
  -- Check if code content matches valid content
  
  -- *8.* Beep for 200ms and blink for 500ms (positive: high pitch and green, negative: low pitch and red) 
  -- if wasValidContent == true then
  --   -- intBeeper:beep(20, 200, 100)
  --   feedbackLED:setColor("green")
  --   feedbackLED:activate(500)
  -- else 
  --   -- intBeeper:beep(1, 200, 100)
  --   feedbackLED:setColor("red")
  --   feedbackLED:activate(500)
  -- end
end

-- Exported functions

---Function that searches input images for QR codes
---@param img Image Input image
---@param sensorData SensorData Information about acquisition device state
---@param visualizeResult function Function from UI script used to display images
local function processImage(img, sensorData, visualizeResult)
  if img:getType() ~= "UINT8" then
    img:toGray()
  end

  -- *2.* Use Coder Reader object to decode image and show results in viewer
  -- local codes, duration = qrReader:decode(img)
  -- visualizeResult(img, codes)

  -- *4.* Extract content of first code (if any) and log comparison result 
  -- local codeContent = nil 
  -- if codes and #codes > 0  then
  --   codeContent = tostring(codes[1]:getContent())
  -- end
  -- print("Valid Input:  ", validContent)
  -- print("Code content: ", codeContent)

  -- *5.* Add if-statement to create device feedback based on comparison of code content and target content
  -- if codeContent == validContent then
  --   visualizeResult(img, codes, true)
  --   generateDeviceFeedback(true)
  --   print("Content is valid!")
  -- else
  --   visualizeResult(img, codes, false)
  --   generateDeviceFeedback(false)
  --   print("Content is invalid!")
  -- end
end

---Returns value of valid content
---@return string
local function getValidContent()
  return validContent
end

---Sets value of valid content
---@param str string
local function setValidContent(str)
  validContent = str
end

return {
  processImage = processImage,
  getValidContent = getValidContent,
  setValidContent = setValidContent
}