-- Private variables and settings

local DirectoryProvider = require("Directory")

local camera = Image.Provider.Camera.create()
local config = Image.Provider.Camera.V2DConfig.create()
local isStarted = false
local isLiveMode = true

config:setGainFactor(1)
config:setShutterTime(100)
config:setBurstLength(1)
config:setVerticalFlip(true)
config:setHorizontalFlip(true)
config:setIntLight("LED_LINE_1_AND_2_ON")
camera:setConfig(config)

local configTimer = Timer.create()
configTimer:setExpirationTime(500)
configTimer:setPeriodic(false)

local acquisitionTimer = Timer.create()
acquisitionTimer:setExpirationTime(1000)
acquisitionTimer:setPeriodic(false)

-- Private functions and handling

local function handleOnStarted()
  camera:enable()
end
Script.register('Engine.OnStarted', handleOnStarted)

---@return boolean
local function setConfig()
  local wasStarted = isStarted

  if isStarted then
    acquisitionTimer:stop()
    isStarted = false
  end

  local success, errors = pcall(Image.Provider.Camera.setConfig,camera,config)

  if not success then
    if errors then
      Log.severe("Setting config to camera failed: " .. errors)
    else
      Log.severe("Setting config to camera failed")
    end
  end

  if wasStarted then
    acquisitionTimer:start()
    isStarted = true
  end

  return success
end
configTimer:register("OnExpired", setConfig)

local function reStartConfigTimer()
  if configTimer:isRunning() then
    configTimer:stop()
  end
  configTimer:start()
end

---@param paramName "ShutterTime" | "GainFactor" | "BurstLength"
---@param value integer
---@return boolean
local function setConfigParam(paramName, value)
  local success, errors = pcall(
    Script.callFunction,
    "Image.Provider.Camera.V2DConfig.set"..paramName,
    config,
    value)
  if not success then
    if errors then
      Log.severe(("Setting parameter %s to config failed: %s"):format(tostring(paramName), errors))
    else
      Log.severe(("Setting parameter %s to config failed"):format(tostring(paramName)))
    end
  else
    reStartConfigTimer()
  end
  return success
end

local function startCamera()
  camera:start()
end
acquisitionTimer:register("OnExpired", startCamera)

local function restartAcquisitionTimer()
  if acquisitionTimer:isRunning() then
    acquisitionTimer:stop()
  end
  acquisitionTimer:start()
end

-- Exported functions

---Starts image provider
---@return boolean
local function start()
  if isStarted then
    Log.warning("Image acquisition already started")
    return false
  else
    if isLiveMode then
      camera:register("OnNewImage", restartAcquisitionTimer)
      acquisitionTimer:start()
    else
      DirectoryProvider.start()
    end
    isStarted = true
    return true
  end
end

---Stops image provider
---@return boolean
local function stop()
  if isStarted then
    if isLiveMode then
      camera:deregister("OnNewImage", restartAcquisitionTimer)
      acquisitionTimer:stop()
    else
      DirectoryProvider.stop()
    end
    isStarted = false
    return true
  else
    Log.warning("Image acquisition already stopped")
    return false
  end
end

---Allows to register to OnNewImage event (sends Image, SensorData)
---@param fun function Function that will trigger when OnNewImage event happens
---@return boolean
local function registerOnNewImage(fun)
  if isLiveMode then
    local success, errors = pcall(Image.Provider.Camera.register, camera, "OnNewImage", fun)
    if not success then
      if errors then
        Log.severe("Registering OnNewImage for camera provider failed: " .. errors)
      else
        Log.severe("Registering OnNewImage for camera provider failed.")
      end
    end
    return success
  else
    return DirectoryProvider.registerOnNewImage(fun)
  end
end

---Allows to deregister from OnNewImage event
---@param fun function Function registered to OnNewImage event
---@return boolean
local function deregisterOnNewImage(fun)
  local success, errors = pcall(Image.Provider.Camera.deregister, camera, "OnNewImage", fun)
  if isLiveMode then
    if not success then
      if errors then
        Log.severe("Deregistering OnNewImage for camera provider failed: " .. errors)
      else
        Log.severe("Deregistering OnNewImage for camera provider failed.")
      end
    end
    return success
  else
    return DirectoryProvider.deregisterOnNewImage(fun)
  end
end

---Returns whether image acquisition is running
---@return boolean running true if acquisition is running, false otherwise
local function isRunning()
  return isStarted
end

---Sets cycle time of an image provider. Will be longer if camera takes longer to take a picture.
---@param cycleTime integer Cycle time in ms
---@return boolean
local function setCycleTime(cycleTime)
  local wasStarted = isStarted
  if isStarted and isLiveMode then
    stop()
  end
  local success, errors = pcall(Timer.setExpirationTime, acquisitionTimer, cycleTime)
  if not success then
    if errors then
      Log.severe("Setting cycleTime for camera provider failed: " .. errors)
    else
      Log.severe("Setting cycleTime for camera provider failed.")
    end
  end

  success = success and DirectoryProvider.setCycleTime(cycleTime)
  if wasStarted and isLiveMode then
    start()
  end
  return success
end

---Sets Gain setting of a camera
---@param gain integer Gain value
---@return boolean
local function setGain(gain)
  if not isLiveMode then
    Log.warning("No gain settings for directory provider")
    return false
  end
  return setConfigParam("GainFactor", gain)
end

---Sets ShutterTime or time of exposure of camera. Limited by the camera hardware to a certain value dependent on the model.
---@param time integer Exposure time in microseconds
---@return boolean
local function setExposureTime(time)
  if not isLiveMode then
    Log.warning("No exposure time settings for directory provider")
    return false
  end
  return setConfigParam("ShutterTime", time)
end

---Sets whether camera should take new pictures or take ones from resources folder
---@param liveMode boolean true - camera will take new pictures, false - pictures will be taken from the resources folder
---@param onNewImageFunctions function[] Functions registered to OnNewImage events
---@return boolean
local function setLiveMode(liveMode, onNewImageFunctions)
  if isLiveMode == liveMode then
    Log.warning(("Live mode already set to %s, ignoring."):format(tostring(liveMode)))
    return false
  end
  local wasStarted = isStarted

  if isStarted then
    stop()
  end


  if liveMode then
    for _, fun in pairs(onNewImageFunctions) do
      DirectoryProvider.deregisterOnNewImage(fun)
      camera:register("OnNewImage", fun)
    end
  else
    for _, fun in pairs(onNewImageFunctions) do
      DirectoryProvider.registerOnNewImage(fun)
      camera:deregister("OnNewImage", fun)
    end
  end

  isLiveMode = liveMode
  
  if wasStarted then
    start()
  end
end

---Captures one image
---@return boolean
local function snapshot()
  if isStarted then
    Log.warning("Can't snapshot while the trigger mode is set to auto")
    return false
  else
    if isLiveMode then
      config:setBurstLength(1)
      camera:setConfig(config)
      
      local function unsetBurst()
        config:setBurstLength(0)
        camera:setConfig(config)
        camera:deregister("OnNewImage", unsetBurst)
      end

      camera:register("OnNewImage", unsetBurst)
      camera:start()
    else
      DirectoryProvider.snapshot()
      return true
    end
  end
end

return {
  start = start,
  stop = stop,
  registerOnNewImage = registerOnNewImage,
  deregisterOnNewImage = deregisterOnNewImage,
  isRunning = isRunning,
  setCycleTime = setCycleTime,
  setGain = setGain,
  setExposureTime = setExposureTime,
  setLiveMode = setLiveMode,
  snapshot = snapshot
}