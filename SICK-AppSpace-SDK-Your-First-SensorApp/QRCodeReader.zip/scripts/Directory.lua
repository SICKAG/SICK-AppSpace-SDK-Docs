-- Private variables and settings

local provider = Image.Provider.Directory.create()

provider:setAutoDeleteActive(false)
provider:setCyclicModeActive(true)
provider:setPath("resources")
provider:setCycleTime(1000)

local isStarted = false

-- Private functions and handling



-- Exported functions

---Starts image provider
---@return boolean
local function start()
  if isStarted then
    Log.warning("Image acquisition already started")
    return false
  else
    provider:start()
    isStarted = true
    return true
  end
end

---Stops image provider
local function stop()
  if isStarted then
    provider:stop()
    isStarted = false
    return true
  else
    Log.warning("Image acquisition already started")
    return false
  end
end

---Allows to register to OnNewImage event
---@param fun function Function that will trigger when OnNewImage event happens
---@return boolean
local function registerOnNewImage(fun)
  local success, errors = pcall(Image.Provider.Directory.register, provider, "OnNewImage", fun)
  if not success then
    if errors then
      Log.severe("Registering OnNewImage for directory provider failed: " .. errors)
    else
      Log.severe("Registering OnNewImage for directory provider failed.")
    end
  end
  return success
end

---Allows to deregister from OnNewImage event
---@param fun function Function registered to OnNewImage event
---@return boolean
local function deregisterOnNewImage(fun)
  local success, errors = pcall(Image.Provider.Directory.deregister, provider, "OnNewImage", fun)
  if not success then
    if errors then
      Log.severe("Deregistering OnNewImage for directory provider failed: " .. errors)
    else
      Log.severe("Deregistering OnNewImage for directory provider failed.")
    end
  end
  return success
end

---Returns whether image acquisition is running
---@return boolean running true if acquisition is running, false otherwise
local function isRunning()
  return isStarted
end

---Sets cycle time of an image provider
---@param cycleTime integer Cycle time in ms
---@return boolean
local function setCycleTime(cycleTime)
  local wasStarted = false
  if isStarted then
    wasStarted = true
    stop()
  end
  local success, errors = pcall(Image.Provider.Directory.setCycleTime, provider, cycleTime)
  if not success then
    if errors then
      Log.severe("Setting cycleTime for directory provider failed: " .. errors)
    else
      Log.severe("Setting cycleTime for directory provider failed.")
    end
  end

  if wasStarted then
    start()
  end
  return success
end

---Captures one image
---@return boolean
local function snapshot()
  if isStarted then
    Log.warning("Can't snapshot while the trigger mode is set to auto")
    return false
  else
    provider.start(1)
    return true
  end
end

return {
  start = start,
  stop = stop,
  registerOnNewImage = registerOnNewImage,
  deregisterOnNewImage = deregisterOnNewImage,
  isRunning = isRunning,
  setCycleTime = setCycleTime,
  snapshot = snapshot
}